﻿using System;
using System.Collections.Generic;
using Soyuz;
using Verse;

namespace Soyus
{
    //public static class PawnModelHelper<T> where T : IPawnModel
    //{
    //    public static Dictionary<Pawn, T> Models = new Dictionary<Pawn, T>();

    //    public static T GetModel(Pawn pawn)
    //    {
    //        if (pawn == null)
    //            return null;
    //        if (pawn.Destroyed)
    //            return null;
    //        return Models.TryGetValue(pawn, out T model) ? model : Models[pawn] = Activator.CreateInstance(Models);
    //    }
    //}
}
