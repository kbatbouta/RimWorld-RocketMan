﻿using System;
using System.Collections.Generic;

namespace Gagarin
{
    public static class TextureHelper
    {
        public static List<string> AllImages = new List<string>();
    }
}
