﻿namespace Proton
{
    public enum FloodingMode
    {
        none = 0,

        normal = 1,

        noCavePlants = 2
    }
}
