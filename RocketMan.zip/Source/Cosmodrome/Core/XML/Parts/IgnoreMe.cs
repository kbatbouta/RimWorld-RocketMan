﻿using System;
namespace RocketMan
{
    public class IgnoreMePart
    {
        public string packageId;
    }
}
