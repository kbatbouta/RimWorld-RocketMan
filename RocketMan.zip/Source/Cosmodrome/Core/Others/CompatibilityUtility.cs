﻿using System;
using System.Collections.Generic;
using HarmonyLib;
using Verse;

namespace RocketMan
{
    public static class CompatibilityUtility
    {

    }
}
