﻿using System;
namespace RocketMan
{
    public enum PatchType
    {
        normal = 0,
        empty = 1
    }
}
