﻿using System;
using Mono.Security.Interface;

namespace RocketMan
{
    public class Alert_AdaptiveMode : Alert
    {
        public Alert_AdaptiveMode()
        {
        }
    }
}
